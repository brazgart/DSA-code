import java.util.*;

/**
 * Data Structures and Algorithms
 * Lab 0
 * 
 * Problem 2
 * 
 * @author (sdb) 
 * @version (Sep 2014)
 */
public class Driver2
{
    public static void main()
    {    WordList wordList = new WordList();
         System.out.println (duplicates(wordList.getWordList()));   // should be 4
    }
    
    /** @return the number of duplicate words in the given list
     */
    public static int duplicates (List <String> words)
    {   
       ////////  PUT YOUR SOLUTION HERE
       
       
       return 0;            // allows this class to compile
    }
}
